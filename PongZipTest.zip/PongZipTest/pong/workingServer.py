# =================================================================================================
# Contributing Authors:	    <Anyone who touched the code>
# Email Addresses:          <Your uky.edu email addresses>
# Date:                     <The date the file was last edited>
# Purpose:                  <How this file contributes to the project>
# Misc:                     <Not Required.  Anything else you might want to include>
# =================================================================================================

import socket
import threading
import json



PACKAGESIZE = 1024 # i dont know if this is a good approach but it prevents maaaggiiiccc numberrss
server_address = ("0.0.0.0",59417)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)      # Creating the server
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)    # Working on localhost need this


try: # try to connect if fail then record why
    server.bind(server_address)
except socket.error as e:
    str(e)



server.listen(2) # needed to have listening, blank = possibility for unlimited connections
print("Waiting for connect, Server Started")

def sendInitData(conn, side) -> None:
    initial = {
        'screenHeight' : 480,
        'screenWidth' : 480,
        'side': side
    }

    # Convert the dictionary to a JSON string
    json_data = json.dumps(initial)

    # Send the JSON data to the client
    conn.sendall(json_data.encode())



Lock = threading.Lock()
connections = []

# connections should be locked since even appending can be a race condition
def threaded_client(conn, side) -> None:
    with Lock:
        if conn not in connections:
           connections.append(conn)

    sendInitData(conn,side)

    while True: # server loop
        # when a client connects, assign the first one to connect as player 1, send them back the game settings, send back a json dictionary 
        try:
            # the data recv should be the JSON with values
            jsonData = conn.recv(PACKAGESIZE)
            print("received ", jsonData, "\n")
            reply = json.loads(jsonData.decode())

            if not reply:
                print("disconnect")
                # this is where you should delete the connection from the list, this should allow the server o be able to play another game
                # numConnects = [] # added here
                # connections = [] # this also would ahve to get reset due to logic below
                break
            
            if reply['side'] == "left":
                # in my head if the reply side is left you have to send left's data to
                # the person on the right and vice-versa. Clearly this is not working, though.
                print("sending ", reply, "to", connections[1], "\n")
                reply = json.dumps(reply)
                connections[1].sendall(reply.encode())
            elif reply['side'] == "right":
                print("sending ", reply, "to", connections[0], "\n")
                reply = json.dumps(reply)
                connections[0].sendall(reply.encode())
            

        except:
            break


    print("Lost Connection")
    conn.close()





while True: # continuously look for connections
    numConnects = []
    # Accept the first player as the left player
    while(len(numConnects) < 2): # this was numConnects
        left_player_conn, left_player_address = server.accept()
        print("Left Player Connected to: ", left_player_address)
        left_player_thread = threading.Thread(target=threaded_client, args=(left_player_conn, 'left'))
        numConnects.append(left_player_thread)

    # Accept the second player as the right player
        right_player_conn, right_player_address = server.accept()
        print("Right Player Connected to: ", right_player_address)
        right_player_thread = threading.Thread(target=threaded_client, args=(right_player_conn, 'right'))
        numConnects.append(right_player_thread)

    left_player_thread.start()
    right_player_thread.start()
    # i am not sure if we can access thread1 and thread2 json data down here?

