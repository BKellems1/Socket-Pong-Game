# =================================================================================================
# Contributing Authors:	    Adrian Treadwell, Brandon Kellems
# Email Addresses:          astr229@uky.edu, bnke231@uky.edu
# Date:                     <The date the file was last edited>
# Purpose:                  <How this file contributes to the project>
# Misc:                     <Not Required.  Anything else you might want to include>
# =================================================================================================

import socket
import json
import pygame


class Client:
    def __init__(self):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server = "10.47.68.170"
        self.port = 59417
        self.addr = (self.server, self.port)









